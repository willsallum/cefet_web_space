// Faça o exercício da equação de GRAVITAÇÃO UNIVERSAL aqui
// Este arquivo AINDA NÃO ESTÁ INCLUÍDO no arquivo HTML

let massa1 = window.document.querySelector('#massa1')
let massa2 = window.document.querySelector('#massa2')
let distancia = window.document.querySelector('#distancia')
let resultado = window.document.querySelector('#resultado')

let button = window.document.querySelector('#calcular')

button.addEventListener('click', function() {

    const gravity = window.Math.pow(10, -11) * 6.67

    resultado.value = (gravity * massa1.value * massa2.value) / window.Math.pow(distancia.value, 2)

})