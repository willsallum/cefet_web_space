// Faça o exercício dos PARÁGRAFOS aqui
// Este arquivo AINDA NÃO ESTÁ INCLUÍDO no arquivo HTML
let but = window.document.querySelectorAll('.botao-expandir-retrair') 

but.forEach((b) => {

    b.addEventListener ('click', function(){

        let father = b.parentNode
        father.classList.toggle('expandido')
    
    })

})