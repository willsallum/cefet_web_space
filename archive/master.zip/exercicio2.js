// Faça o exercício da GALERIA DE IMAGENS aqui
// Este arquivo AINDA NÃO ESTÁ INCLUÍDO no arquivo HTML

const servidorDasImagens = 'https://willsallum.github.io/cefet_front_end/images';
const imagens = [
    {
      arquivo: '01-philae-parts.jpg',
      descricao: 'Imagem em 3D mostrando a sonda tocando um asteróide. ' +
        'A sonda tem forma de caixa com dois painéis solares em suas ' +
        'laterais e, na parte de baixo, um pequeno braço sai e encosta ' +
        'no asteróide'
    },
    {
      arquivo: '02-philae-rosetta.jpg',
      descricao: 'Foto de foguete na vertical no momento de seu ' +
        'lançamento. Ele possui bandeiras da NASA, dos EUA e da empresa ' +
        'ULA e está com o motor sendo ligado, saindo fogo e fumaça'
    },
    {
      arquivo: '03-philae-separation.jpg',
      descricao: 'Foto do espaço quase toda preta mostrando a Terra bem ' +
        'pequena no canto esquerdo e, no canto direito, a lua ainda menor'
    },
    {
      arquivo: '04-philae-67-picture.jpg',
      descricao: 'Foto do espaço mostrando o asteróide Bennu que tem ' +
        'a forma de um paralelepípedo com base losangular aproximadamente ' +
        'e a superfície acinzentada'
    },
    {
      arquivo: '05-philae-collecting.jpg',
      descricao: 'Animação de uma forma tridimensional um pouco ovalada ' +
        'representada usando diversas cores e girando em torno do eixo vertical ' +
        'representando a superfície do asteróide'
    }
  ];

