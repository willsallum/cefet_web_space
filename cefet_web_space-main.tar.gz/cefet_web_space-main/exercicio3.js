// Faça o exercício dos PARÁGRAFOS aqui
// Este arquivo AINDA NÃO ESTÁ INCLUÍDO no arquivo HTML

let button3 = document.querySelectorAll('.botao-expandir-retrair');

for(let i = 0; i < 5; i++){

    button3[i].addEventListener('click', function(){

        let selectedEL = button3[i].parentNode;
    
        selectedEL.classList.toggle('expandido');
    
    })
    
}
