// Faça o exercício da equação de GRAVITAÇÃO UNIVERSAL aqui
// Este arquivo AINDA NÃO ESTÁ INCLUÍDO no arquivo HTML

let m1 = document.querySelector('#massa1');

let m2 = document.querySelector('#massa2');

let d = document.querySelector('#distancia');

let result = document.querySelector('#resultado')

let button = document.querySelector('#calcular');

button = addEventListener('click', function(){

    const g = (6.67 * (10 ** -11));

    result.value = (g * m1.value * m2.value)/ d.value    ** 2;

})

